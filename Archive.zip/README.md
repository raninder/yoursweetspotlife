## Your Sweet Spot Life Website
# Log 
01/24/24: Created Homepage: Nav bar, Landing Page, Placeholder buttons for road map, Created Contact Page
